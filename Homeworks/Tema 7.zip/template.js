function addCrew() {
  var table = document.getElementById("crew-list");
  var btn = document.createElement("BUTTON"); //Create a <button> element
  var cell5 = document.body.appendChild(btn);
  var txt = document.createTextNode("Remove");
  var x = document.getElementById("crew-list").rows.length;

  var img = new Image();
    img.src = cell4;

  var row = table.insertRow(0);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  var cell3 = row.insertCell(2);
  var cell4 = row.insertCell(3);
  var cell5 = row.insertCell(4);

  cell1.innerHTML = x;
  cell2.innerHTML = document.getElementById("chrName").value;
  cell3.innerHTML = document.getElementById("ActName").value;
  cell4.inputbox = img;

  
  cell5.appendChild(btn);
  btn.appendChild(txt); // Insert text for button
  
  // Button Remove event listener
  btn.addEventListener('click', remButton);
  
  function remButton(btnName) {
  this.parentElement.parentElement.remove()
    //document.getElementById("crew-list").remove(HTMLTableRowElement); //Delete all table
  }

  table.appendChild(row); //new table row
}
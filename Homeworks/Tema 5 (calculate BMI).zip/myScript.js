function calculateBmi() {
var weight = document.techBMI.weight.value
var height = document.techBMI.height.value
if(weight > 0 && height > 0){	
var finalBmi = weight/(height*height)
document.techBMI.bmi.value = finalBmi.toFixed(3);
if(finalBmi < 18.5){
document.techBMI.meaning.value = "You are unhealthy, too thin."
    }
if(finalBmi > 18.5 && finalBmi < 25){
document.techBMI.meaning.value = "You are healthy enough."
    }
if(finalBmi > 25 &&  finalBmi <30){
document.techBMI.meaning.value = "You have overweight."
    }
if(finalBmi > 30){
document.techBMI.meaning.value = "Your condition is serious."
    }
    }
    else{
    alert("Please complete all the fields above.")
    }
}
	 
function addPerson() {
	var x = document.getElementById("Yname").value
	var w = document.getElementById("weight").value
	var h = document.getElementById("height").value
	if (x === "" || w === "" || h === "") {
	return alert ("Please complete all the required fields.");
	} else {
	document.getElementById("NewPerson").innerHTML = x + " | Kg: " + w + " | Hight: " + h;}

}


//delete Person
function deletePerson() {
document.getElementById("NewPerson").innerHTML = "                          ";}